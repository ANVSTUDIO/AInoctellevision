(() => {
  "use strict";

  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];
  const isDesktop = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- Footer year ---------- */
  $("#year").textContent = new Date().getFullYear();

  /* ---------- Intro loader ---------- */
  window.addEventListener("load", () => {
    setTimeout(() => {
      $("#loader").classList.add("hide");
      // Reveal hero elements after loader finishes
      $$(".hero .reveal").forEach((el, i) => {
        setTimeout(() => el.classList.add("in"), 250 + i * 160);
      });
    }, 1700);
  });

  /* ---------- Header scroll state ---------- */
  const header = $("#header");
  const onScroll = () => header.classList.toggle("scrolled", window.scrollY > 30);
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  /* ---------- Mobile menu ---------- */
  const toggle = $("#menuToggle");
  const nav = $("#nav");
  const closeMenu = () => {
    nav.classList.remove("open");
    toggle.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
  };
  toggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    toggle.classList.toggle("open", open);
    toggle.setAttribute("aria-expanded", String(open));
  });
  $$("a", nav).forEach((a) => a.addEventListener("click", closeMenu));

  /* ---------- Active nav link on scroll ---------- */
  const sections = $$("main section[id]");
  const links = $$("a[href^='#']", nav);
  const spy = new IntersectionObserver(
    (entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          links.forEach((l) => l.classList.toggle("active", l.getAttribute("href") === "#" + e.target.id));
        }
      });
    },
    { rootMargin: "-45% 0px -50% 0px" }
  );
  sections.forEach((s) => spy.observe(s));

  /* ---------- Scroll reveal ---------- */
  const revealObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          // Small stagger for siblings
          const siblings = [...entry.target.parentElement.children].filter((c) => c.classList.contains("reveal"));
          const delay = Math.max(0, siblings.indexOf(entry.target)) * 120;
          setTimeout(() => entry.target.classList.add("in"), delay);
          revealObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );
  $$(".reveal").forEach((el) => {
    if (!el.closest(".hero")) revealObserver.observe(el); // hero handled by loader
  });

  /* ---------- Hero particles ---------- */
  const canvas = $("#particles");
  if (canvas && !reduceMotion) {
    const ctx = canvas.getContext("2d");
    let w, h, dots;
    const mouse = { x: -999, y: -999 };

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = canvas.clientWidth;
      h = canvas.clientHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.min(90, Math.floor((w * h) / 16000));
      dots = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.35,
        vy: (Math.random() - 0.5) * 0.35,
        r: Math.random() * 1.6 + 0.4,
      }));
    };
    resize();
    window.addEventListener("resize", resize);
    if (isDesktop) {
      window.addEventListener("mousemove", (e) => {
        const rect = canvas.getBoundingClientRect();
        mouse.x = e.clientX - rect.left;
        mouse.y = e.clientY - rect.top;
      });
    }

    const draw = () => {
      ctx.clearRect(0, 0, w, h);
      for (let i = 0; i < dots.length; i++) {
        const d = dots[i];
        d.x += d.vx; d.y += d.vy;
        if (d.x < 0 || d.x > w) d.vx *= -1;
        if (d.y < 0 || d.y > h) d.vy *= -1;

        // Gentle push away from cursor
        const dx = d.x - mouse.x, dy = d.y - mouse.y;
        const dist = Math.hypot(dx, dy);
        if (dist < 120) { d.x += (dx / dist) * 1.2; d.y += (dy / dist) * 1.2; }

        ctx.beginPath();
        ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(232, 184, 92, 0.75)";
        ctx.fill();

        for (let j = i + 1; j < dots.length; j++) {
          const o = dots[j];
          const dd = Math.hypot(d.x - o.x, d.y - o.y);
          if (dd < 110) {
            ctx.strokeStyle = `rgba(160, 130, 255, ${0.18 * (1 - dd / 110)})`;
            ctx.lineWidth = 0.7;
            ctx.beginPath();
            ctx.moveTo(d.x, d.y);
            ctx.lineTo(o.x, o.y);
            ctx.stroke();
          }
        }
      }
      requestAnimationFrame(draw);
    };
    draw();
  }

  /* ---------- Desktop-only cursor effects ---------- */
  if (!isDesktop || reduceMotion) return;

  document.body.classList.add("has-cursor");
  const dot = $("#cursorDot");
  const ring = $("#cursorRing");
  const spot = $("#spotlight");
  const cards = $$(".glow-card");

  let mx = innerWidth / 2, my = innerHeight / 2; // target
  let rx = mx, ry = my;                          // ring (smoothed)
  let ticking = false;

  window.addEventListener("mousemove", (e) => {
    mx = e.clientX;
    my = e.clientY;
    dot.style.left = mx + "px";
    dot.style.top = my + "px";
    spot.style.setProperty("--sx", mx + "px");
    spot.style.setProperty("--sy", my + "px");
    if (!ticking) {
      ticking = true;
      requestAnimationFrame(updateCards);
    }
  });

  // Smooth trailing ring
  const follow = () => {
    rx += (mx - rx) * 0.16;
    ry += (my - ry) * 0.16;
    ring.style.left = rx + "px";
    ring.style.top = ry + "px";
    requestAnimationFrame(follow);
  };
  follow();

  // Ring grows on interactive elements
  $$("a, button, .glow-card").forEach((el) => {
    el.addEventListener("mouseenter", () => ring.classList.add("active"));
    el.addEventListener("mouseleave", () => ring.classList.remove("active"));
  });

  // Proximity glow + soft tilt: cards react when the cursor approaches
  function updateCards() {
    ticking = false;
    const RANGE = 260; // px distance at which a card starts reacting
    cards.forEach((card) => {
      const r = card.getBoundingClientRect();
      if (r.bottom < -RANGE || r.top > innerHeight + RANGE) return;

      const cx = Math.max(r.left, Math.min(mx, r.right));
      const cy = Math.max(r.top, Math.min(my, r.bottom));
      const dist = Math.hypot(mx - cx, my - cy);
      const prox = Math.max(0, 1 - dist / RANGE);
      const inside = dist === 0;

      card.style.setProperty("--prox", prox.toFixed(3));
      card.style.setProperty("--mx", mx - r.left + "px");
      card.style.setProperty("--my", my - r.top + "px");

      if (inside) {
        const px = (mx - r.left) / r.width - 0.5;
        const py = (my - r.top) / r.height - 0.5;
        card.style.setProperty("--ry", (px * 7).toFixed(2) + "deg");
        card.style.setProperty("--rx", (-py * 7).toFixed(2) + "deg");
      } else {
        card.style.setProperty("--rx", "0deg");
        card.style.setProperty("--ry", "0deg");
      }
    });
  }
  window.addEventListener("scroll", () => { if (!ticking) { ticking = true; requestAnimationFrame(updateCards); } }, { passive: true });
})();